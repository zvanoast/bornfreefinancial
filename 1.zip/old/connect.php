<?php

$mysql_host = 'localhost';
$mysql_user = 'twhooker_beta';
$mysql_pass = 'beta098';

$mysql_db = 'twhooker_beta';

if (mysql_connect($mysql_host, $mysql_user, $mysql_pass) && mysql_select_db($mysql_db) ) 
{
	die(mysql_error());
}

?>