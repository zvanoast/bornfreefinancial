<?php
/**
 * These are the database login details
 */  
define("HOST", "localhost");     // Database host
define("USER", "twhooker_admin");    // Database username
define("PASSWORD", "Hailmary23");    // Database password. 
define("DATABASE", "twhooker_beta");    // Database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    // HTTPS. Only FALSE for development. Must be TRUE and implemented for production