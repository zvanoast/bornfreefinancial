<?php
include_once 'sec_login_config.php';
$mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);